import React from "react";
import PieChart from "./PieChart"; // Assuming PieChart is imported from the correct location

const TestData = () => {
  const testChartData = [
    { label: "Category 1", value: 25 },
    { label: "Category 2", value: 30 },
    { label: "Category 3", value: 45 },
  ];

  return (
    <PieChart
      title="Sample Pie Chart"
      description="This is a sample pie chart showing distribution of categories."
      height={300} // Adjust height as needed
      chart={testChartData}
    />
  );
};

export default TestData;

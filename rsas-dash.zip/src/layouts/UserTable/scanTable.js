import React, { useState, useEffect } from "react";
import PropTypes from "prop-types";
import TextField from "@mui/material/TextField";
import SearchIcon from "@mui/icons-material/Search";
import SkipNextIcon from "@mui/icons-material/SkipNext";
import SkipPreviousIcon from "@mui/icons-material/SkipPrevious";

const ScanTable = ({ datax, setpageNumber_scan, pageNumber_scan }) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredData, setFilteredData] = useState([]);

  const columns = ["date", "interaction_time", "phone", "account_name"];

  useEffect(() => {
    if (datax && datax.length > 0) {
      const newData = datax.filter((row) => row.phone.includes(searchTerm));
      setFilteredData(newData);
    } else {
      setFilteredData([]);
    }
  }, [datax, searchTerm]);

  const handleSearchTermChange = (event) => {
    setSearchTerm(event.target.value);
  };

  const handleForwardClick = () => {
    setpageNumber_scan(pageNumber_scan + 1);
  };

  const handleBackwardClick = () => {
    if (pageNumber_scan > 1) {
      setpageNumber_scan(pageNumber_scan - 1);
    }
  };

  const styles = {
    container: {
      fontFamily: "Arial, sans-serif",
      backgroundColor: "#f4f4f4",
      padding: "20px",
      borderRadius: "8px",
      boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
      maxWidth: "100%",
      margin: "0 auto",
    },
    header: {
      display: "flex",
      marginBottom: "10px",
      borderBottom: "1px solid #ddd",
      paddingBottom: "5px",
    },
    columnHeader: {
      flex: 1,
      fontWeight: "bold",
      textAlign: "center",
    },
    dataRow: {
      display: "flex",
      marginBottom: "5px",
    },
    dataCell: {
      flex: 1,
      backgroundColor: "#fff",
      border: "1px solid #ddd",
      borderRadius: "2px",
      padding: "3px",
      margin: "0 2px",
      minWidth: "100px",
      textAlign: "center",
    },
    noData: {
      textAlign: "center",
      marginTop: "10px",
      color: "gray",
    },
  };

  return (
    <div style={styles.container}>
      <h4>Scan Table</h4>
      <TextField
        placeholder="Search by phone number"
        variant="outlined"
        value={searchTerm}
        onChange={handleSearchTermChange}
        InputProps={{
          startAdornment: <SearchIcon style={{ marginRight: "10px", color: "gray" }} />,
        }}
        style={{ marginBottom: "10px" }}
      />
      <div style={styles.header}>
        {columns.map((column, index) => (
          <div key={index} style={styles.columnHeader}>
            {column}
          </div>
        ))}
      </div>
      {filteredData.length > 0 ? (
        <div style={styles.dataContainer}>
          {filteredData.map((row, rowIndex) => (
            <div key={rowIndex} style={styles.dataRow}>
              {columns.map((column, columnIndex) => (
                <div key={columnIndex} style={styles.dataCell}>
                  {row[column]}
                </div>
              ))}
            </div>
          ))}
        </div>
      ) : (
        <div style={styles.noData}>No data available for this filter</div>
      )}
      <div style={{ display: "flex", justifyContent: "flex-end" }}>
        <button onClick={handleBackwardClick} style={{ fontSize: "24px" }}>
          <SkipPreviousIcon />
        </button>
        <button onClick={handleForwardClick} style={{ fontSize: "24px", marginRight: "10px" }}>
          <SkipNextIcon />
        </button>
        <span style={{ fontSize: "18px" }}>Page {pageNumber_scan}</span>
      </div>
    </div>
  );
};

ScanTable.propTypes = {
  datax: PropTypes.arrayOf(
    PropTypes.shape({
      date: PropTypes.string,
      interaction_time: PropTypes.string,
      phone: PropTypes.string,
      account_name: PropTypes.string,
    })
  ).isRequired,
  setpageNumber_scan: PropTypes.func.isRequired,
  pageNumber_scan: PropTypes.number.isRequired,
};

export default ScanTable;

import React, { useState, useEffect } from "react";
import axios from "axios";
import Grid from "@mui/material/Grid";
import MDBox from "components/MDBox";
import DashboardLayout from "examples/LayoutContainers/DashboardLayout";
import DashboardNavbar from "examples/Navbars/DashboardNavbar";
import Footer from "examples/Footer";
import TextField from "@mui/material/TextField";
import reportsLineChartData from "layouts/dashboard/data/reportsLineChartData";
import UserTable from "./userTable";
import ScanTable from "./scanTable";

function UserTableDashboard() {
  const { sales, tasks } = reportsLineChartData;

  const [userList, setUserList] = useState([]);
  const [scanList, setScanList] = useState([]);
  const [pageNumber_user, setPageNumber_user] = useState(1);
  const [pageNumber_scan, setpageNumber_scan] = useState(1);
  const [selectedDate, setSelectedDate] = useState(() => {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    return yesterday.toISOString().split("T")[0];
  });
  const [loading, setLoading] = useState(false); // Initialize loading state

  useEffect(() => {
    fetchData(); // Call fetchData function
  }, [selectedDate, pageNumber_user, pageNumber_scan]);

  const fetchData = async () => {
    setLoading(true); // Set loading to true when fetching data
    try {
      const userInfoResponse = await axios.post("http://localhost:8088/user_info", {
        from_time: selectedDate,
        page_no: pageNumber_user,
      });
      const scanInfoResponse = await axios.post("http://localhost:8088/scan_info", {
        from_time: selectedDate,
        page_no: pageNumber_scan,
      });

      console.log("user data", userInfoResponse);
      console.log("scan data", scanInfoResponse);

      setUserList(userInfoResponse.data.user_info);
      setScanList(scanInfoResponse.data.scan_info);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false); // Set loading to false after data fetching
    }
  };

  const handleDateChange = (event) => {
    setSelectedDate(event.target.value);
    setpageNumber_scan(1); // Reset the page number to 1 when date changes
    setPageNumber_user(1);
  };

  return (
    <DashboardLayout>
      <DashboardNavbar />
      <MDBox py={3}>
        <TextField
          id="date"
          label="Select Date"
          type="date"
          defaultValue={selectedDate}
          onChange={handleDateChange}
          InputLabelProps={{
            shrink: true,
          }}
          style={{
            width: "30%", // Make it take full width
            textAlign: "center", // Center the text
            fontSize: "24px", // Increase the font size
            marginBottom: "40px", // Add some top margin for spacing
            marginLeft: "30%",
          }}
        />
        <Grid container spacing={3}>
          <Grid item xs={12} md={6} lg={6}>
            <ScanTable
              datax={scanList}
              setpageNumber_scan={setpageNumber_scan}
              pageNumber_scan={pageNumber_scan}
              loading={loading}
            />
          </Grid>
          <Grid item xs={12} md={6} lg={6}>
            <UserTable
              datax={userList}
              setPageNumber_user={setPageNumber_user}
              PageNumber_user={pageNumber_user}
              loading={loading}
            />
          </Grid>
        </Grid>
      </MDBox>
      <Footer />
    </DashboardLayout>
  );
}

export default UserTableDashboard;

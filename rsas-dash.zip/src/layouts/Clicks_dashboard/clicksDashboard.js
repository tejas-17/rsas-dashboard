import React, { useState, useEffect } from "react";
import axios from "axios";
import Grid from "@mui/material/Grid";
import MDBox from "components/MDBox";
import DashboardLayout from "examples/LayoutContainers/DashboardLayout";
import DashboardNavbar from "examples/Navbars/DashboardNavbar";
import Footer from "examples/Footer";
import ComplexStatisticsCard from "examples/Cards/StatisticsCards/ComplexStatisticsCard";
import TextField from "@mui/material/TextField";
import CircularProgress from "@mui/material/CircularProgress"; // Add CircularProgress import

function Clicks() {
  const [agreeClicks, setAgreeClicks] = useState(null); // Change initial state to null
  const [disagreeClicks, setDisagreeClicks] = useState(null); // Change initial state to null
  const [milestoneClicks, setMilestoneClicks] = useState(null); // Change initial state to null
  const [rewardsClicks, setRewardsClicks] = useState(null); // Change initial state to null
  const [yesClicks, setYesClicks] = useState(null); // Change initial state to null
  const [noClicks, setNoClicks] = useState(null); // Change initial state to null
  const [loading, setLoading] = useState(true); // Loading state
  const [selectedDate, setSelectedDate] = useState(() => {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    return yesterday.toISOString().split("T")[0];
  });

  useEffect(() => {
    setLoading(true); // Set loading to true when fetching data
    getClicksMetric();
  }, [selectedDate]);

  const getClicksMetric = async () => {
    try {
      const response = await axios.post("http://localhost:8088/get_clicks_metric", {
        from_time: selectedDate,
      });
      console.log("clickkkkk object", response);
      if (response.data.clicks_info[0] == null) {
        setAgreeClicks(null); // Update state with null if value is undefined
        setDisagreeClicks(null); // Update state with null if value is undefined
        setMilestoneClicks(null); // Update state with null if value is undefined
        setRewardsClicks(null); // Update state with null if value is undefined
        setYesClicks(null); // Update state with null if value is undefined
        setNoClicks(null); // Update state with null if value is undefined
      } else {
        setAgreeClicks(response.data.clicks_info[0].agree_clicks); // Update state with null if value is undefined
        setDisagreeClicks(response.data.clicks_info[0].disagree_clicks); // Update state with null if value is undefined
        setMilestoneClicks(response.data.clicks_info[0].mymilestones_clicks); // Update state with null if value is undefined
        setRewardsClicks(response.data.clicks_info[0].myrewards_clicks); // Update state with null if value is undefined
        setYesClicks(response.data.clicks_info[0].yes_clicks); // Update state with null if value is undefined
        setNoClicks(response.data.clicks_info[0].no_clicks); // Update state with null if value is undefined
      }
      setLoading(false); // Set loading to false after data is fetched
    } catch (error) {
      console.error("Error fetching click metrics:", error);
      setLoading(false); // Set loading to false in case of error
    }
  };

  const handleDateChange = (event) => {
    setSelectedDate(event.target.value);
  };

  return (
    <DashboardLayout>
      <DashboardNavbar />
      <MDBox py={3}>
        <TextField
          id="date"
          label="Select Date"
          type="date"
          defaultValue={selectedDate}
          onChange={handleDateChange}
          InputLabelProps={{
            shrink: true,
          }}
          style={{
            width: "30%",
            textAlign: "center",
            fontSize: "24px",
            marginBottom: "40px",
            marginLeft: "30%",
          }}
        />
        {loading ? (
          <CircularProgress /> // Display loading indicator if loading is true
        ) : (
          <Grid container spacing={3}>
            <Grid item xs={12} md={6} lg={3}>
              <MDBox mb={1.5}>
                <ComplexStatisticsCard
                  icon="thumb_up"
                  title={
                    <span style={{ fontSize: "20px", fontWeight: "bold" }}>
                      Agree button clicks
                    </span>
                  }
                  count={agreeClicks !== null ? `${agreeClicks}` : "null"} // Display "null" if agreeClicks is null
                  percentage={{
                    color: "success",
                    amount: "+3%",
                    label: "than last month",
                  }}
                />
              </MDBox>
            </Grid>
            <Grid item xs={12} md={6} lg={3}>
              <MDBox mb={1.5}>
                <ComplexStatisticsCard
                  icon="thumb_down"
                  title={
                    <span style={{ fontSize: "20px", fontWeight: "bold" }}>
                      Disagree button clicks
                    </span>
                  }
                  count={disagreeClicks !== null ? `${disagreeClicks}` : "null"} // Display "null" if disagreeClicks is null
                  percentage={{
                    color: "success",
                    amount: "+3%",
                    label: "than last month",
                  }}
                />
              </MDBox>
            </Grid>
            <Grid item xs={12} md={6} lg={3}>
              <MDBox mb={1.5}>
                <ComplexStatisticsCard
                  icon="public"
                  title={
                    <span style={{ fontSize: "20px", fontWeight: "bold" }}>
                      My Milestone Button Clicks
                    </span>
                  }
                  count={milestoneClicks !== null ? `${milestoneClicks}` : "null"} // Display "null" if milestoneClicks is null
                  percentage={{
                    color: "success",
                    amount: "+3%",
                    label: "than last month",
                  }}
                  color="warning"
                />
              </MDBox>
            </Grid>
            <Grid item xs={12} md={6} lg={3}>
              <MDBox mb={1.5}>
                <ComplexStatisticsCard
                  icon="redeem"
                  title={
                    <span style={{ fontSize: "20px", fontWeight: "bold" }}>
                      My Rewards Button Clicks
                    </span>
                  }
                  count={rewardsClicks !== null ? `${rewardsClicks}` : "null"} // Display "null" if rewardsClicks is null
                  percentage={{
                    color: "success",
                    amount: "+3%",
                    label: "than last month",
                  }}
                  color="warning"
                />
              </MDBox>
            </Grid>
            <Grid item xs={12} md={6} lg={3}>
              <MDBox mb={1.5}>
                <ComplexStatisticsCard
                  icon="check_circle" // Use tick icon for "Yes" button clicks
                  title={
                    <span style={{ fontSize: "20px", fontWeight: "bold" }}>Yes Button Clicks</span>
                  }
                  count={yesClicks !== null ? `${yesClicks}` : "null"} // Display "null" if yesClicks is null
                  percentage={{
                    color: "success",
                    amount: "+3%",
                    label: "than last month",
                  }}
                  color="error" // Change color to red
                />
              </MDBox>
            </Grid>
            <Grid item xs={12} md={6} lg={3}>
              <MDBox mb={1.5}>
                <ComplexStatisticsCard
                  icon="cancel" // Use prohibited icon for "No" button clicks
                  title={
                    <span style={{ fontSize: "20px", fontWeight: "bold" }}>No Button Clicks</span>
                  }
                  count={noClicks !== null ? `${noClicks}` : "null"} // Display "null" if noClicks is null
                  percentage={{
                    color: "success",
                    amount: "+3%",
                    label: "than last month",
                  }}
                  color="error" // Change color to red
                />
              </MDBox>
            </Grid>
          </Grid>
        )}
      </MDBox>
      <Footer />
    </DashboardLayout>
  );
}

export default Clicks;

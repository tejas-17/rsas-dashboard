import React, { useState, useEffect } from "react";
import axios from "axios";
import Grid from "@mui/material/Grid";
import MDBox from "components/MDBox";
import DashboardLayout from "examples/LayoutContainers/DashboardLayout";
import DashboardNavbar from "examples/Navbars/DashboardNavbar";
import Footer from "examples/Footer";
import ComplexStatisticsCard from "examples/Cards/StatisticsCards/ComplexStatisticsCard";
import TextField from "@mui/material/TextField";
import reportsLineChartData from "layouts/dashboard/data/reportsLineChartData";
import DataDisplay from "./DropOutTable";
import ErrorIcon from "@mui/icons-material/Error"; // Importing the Error icon from Material-UI
import { FcCancel } from "react-icons/fc";

import "./dashboard.css";

function Dashboard() {
  const { sales, tasks } = reportsLineChartData;

  const [newScansCount, setNewScansCount] = useState("loading");
  const [dropout1, setDropout1] = useState("loading");
  const [dropout2, setDropout2] = useState("loading");
  const [dropout1_count, setDropout1Count] = useState("loading");
  const [dropout2_count, setDropout2Count] = useState("loading");
  const [dailyActive, setDailyActive] = useState("loading");
  const [dropoutList, setDropoutList] = useState([]);
  const [pageNumber, setPageNumber] = useState(1);
  const [Interaction_count, setInteraction_count] = useState("loading");
  const [selectedDate, setSelectedDate] = useState(() => {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    return yesterday.toISOString().split("T")[0];
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const newScansCountResponse = await fetchScanCount();
        console.log("scan count response function",newScansCountResponse)
        setNewScansCount(newScansCountResponse);

        const dropoutMetricResponse = await fetchDropOutMetric();
        setDropout1(dropoutMetricResponse.dropout1_per || null);
        setDropout2(dropoutMetricResponse.dropout2_per || null);
        setDropout1Count(dropoutMetricResponse.dropout1_count || null);
        setDropout2Count(dropoutMetricResponse.dropout2_count || null);

        const dailyMetricResponse = await fetchDailyMetric();
        setDailyActive(dailyMetricResponse.dau || null);
        setInteraction_count(dailyMetricResponse.interactions_count || null);

        const dropoutListResponse = await fetchDropOutList();
        setDropoutList(dropoutListResponse.dropout_list || []);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, [selectedDate, pageNumber]);

  const fetchScanCount = async () => {
    try {
      const response = await axios.post("http://localhost:8088/scan_count", {
        from_time: selectedDate,
      });
      console.log("Scan count response:", response);
      return response.data?.scan_count?.[0]?.daily_scans_count || null;
    } catch (error) {
      console.error("Error fetching new scans count:", error);
      return null;
    }
  };

  const fetchDropOutMetric = async () => {
    try {
      const response = await axios.post("http://localhost:8088/dropout_metric", {
        from_time: selectedDate,
      });
      console.log("drop out metric==========", response);
      return response.data.dropout_metric?.[0] || {};
    } catch (error) {
      console.error("Error fetching dropout metric:", error);
      return {};
    }
  };

  const fetchDailyMetric = async () => {
    try {
      const response = await axios.post("http://localhost:8088/daily_metric", {
        from_time: selectedDate,
      });
      console.log("daily Active", response);
      return response.data.daily_metric?.[0] || {};
    } catch (error) {
      console.error("Error fetching daily metric:", error);
      return {};
    }
  };

  const fetchDropOutList = async () => {
    try {
      const response = await axios.post("http://localhost:8088/dropout_list", {
        from_time: selectedDate,
        page_no: pageNumber,
      });
      console.log("Dropout list response:", response);
      return response.data || [];
    } catch (error) {
      console.error("Error fetching dropout list:", error);
      return [];
    }
  };

  const handleDateChange = (event) => {
    setSelectedDate(event.target.value);
    setPageNumber(1); // Reset the page number to 1 when date changes
  };

  return (
    <DashboardLayout>
      <DashboardNavbar />
      <MDBox py={3}>
        <TextField
          id="date"
          label="Select Date"
          type="date"
          defaultValue={selectedDate}
          onChange={handleDateChange}
          InputLabelProps={{
            shrink: true,
          }}
          style={{
            width: "30%", // Make it take full width
            textAlign: "center", // Center the text
            fontSize: "24px", // Increase the font size
            marginBottom: "40px", // Add some top margin for spacing
            marginLeft: "30%",
          }}
        />
        <Grid container spacing={3}>
          <Grid item xs={12} md={6} lg={3}>
            <MDBox mb={1.5}>
              <ComplexStatisticsCard
                color="dark"
                icon="weekend"
                title={
                  <span style={{ fontSize: "20px", fontWeight: "bold" }}>New Scans Today</span>
                }
                count={newScansCount}
                percentage={{
                  color: "success",
                  amount: "+55%",
                  label: "than last week",
                }}
              />
            </MDBox>
          </Grid>
          <Grid item xs={12} md={6} lg={3}>
            <MDBox mb={1.5}>
              <ComplexStatisticsCard
                icon="leaderboard"
                title={<span style={{ fontSize: "20px", fontWeight: "bold" }}>DROP OUT 1</span>}
                count={`${dropout1}%`} // Concatenate the percentage string with the count
                percentage={{
                  color: "success",
                  amount: "+3%",
                  label: "than last month",
                }}
              />
            </MDBox>
          </Grid>
          <Grid item xs={12} md={6} lg={3}>
            <MDBox mb={1.5}>
              <ComplexStatisticsCard
                icon="leaderboard"
                title={<span style={{ fontSize: "20px", fontWeight: "bold" }}>DROP OUT 2</span>}
                count={`${dropout2}%`} // Concatenate the percentage string with the count
                percentage={{
                  color: "success",
                  amount: "+3%",
                  label: "than last month",
                }}
              />
            </MDBox>
          </Grid>
          <Grid item xs={12} md={6} lg={3}>
            <MDBox mb={1.5}>
              <ComplexStatisticsCard
                color="primary"
                icon="person_add"
                title={
                  <span style={{ fontSize: "20px", fontWeight: "bold" }}>Daily Active Users</span>
                }
                count={dailyActive}
                percentage={{
                  color: "success",
                  amount: "",
                  label: "Just updated",
                }}
              />
            </MDBox>
          </Grid>
          <Grid item xs={12} md={6} lg={3}>
            <MDBox mb={1.5}>
              <ComplexStatisticsCard
                color="primary"
                icon="person_add"
                title={
                  <span style={{ fontSize: "20px", fontWeight: "bold" }}>
                    Daily Interaction Count
                  </span>
                }
                count={Interaction_count}
                percentage={{
                  color: "success",
                  amount: "",
                  label: "Just updated",
                }}
              />
            </MDBox>
          </Grid>
          <Grid item xs={12} md={6} lg={3}>
            <MDBox mb={1.5}>
              <ComplexStatisticsCard
                icon={<ErrorIcon sx={{ color: "white" }} />} // Using the ErrorIcon with red color
                title={
                  <span style={{ fontSize: "20px", fontWeight: "bold" }}>DROP OUT 1 COUNT</span>
                }
                count={`${dropout1_count}`}
                percentage={{
                  color: "error", // Red color for error
                  amount: "+3%",
                  label: "than last month",
                }}
              />
            </MDBox>
          </Grid>
          <Grid item xs={12} md={6} lg={3}>
            <MDBox mb={1.5}>
              <ComplexStatisticsCard
                icon={<ErrorIcon sx={{ color: "white" }} />} // Using the ErrorIcon with red color
                title={
                  <span style={{ fontSize: "20px", fontWeight: "bold" }}>DROP OUT 2 COUNT</span>
                }
                count={`${dropout2_count}`}
                percentage={{
                  color: "error", // Red color for error
                  amount: "+3%",
                  label: "than last month",
                }}
              />
            </MDBox>
          </Grid>
        </Grid>

        <MDBox>
          <Grid container spacing={3}>
            <Grid item xs={12} md={6} lg={8}>
              <DataDisplay
                datax={dropoutList}
                setpageNumber={setPageNumber}
                pageNumber={pageNumber}
              />
            </Grid>
          </Grid>
        </MDBox>
      </MDBox>
      <Footer />
    </DashboardLayout>
  );
}

export default Dashboard;

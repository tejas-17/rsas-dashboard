import React, { useState, useEffect } from "react";
import PropTypes from "prop-types";
import DataDisplay from "../DropOutTable";
import {
  TableContainer,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  TextField,
  TablePagination,
  Paper,
} from "@mui/material";

const ReactTable = ({ data, setpageNumber, pageNumber }) => {
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(15);
  const [searchTerm, setSearchTerm] = useState("");
  const columns = ["Mobile", "Check-in Time", "Dropout 1", "Dropout 2"];
  const datax = data.map((obj) => Object.values(obj));

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
    alert("pageee");
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const filteredData = data
    ? data.filter((item) => {
        const values = Object.values(item);
        for (let value of values) {
          if (String(value).toLowerCase().includes(searchTerm.toLowerCase())) {
            return true;
          }
        }
        return false;
      })
    : [];

  return (
    <div>
      <DataDisplay data={datax} />
      {/* <h2>DROP OUT TABLE</h2>
      <TextField
        label="Search"
        variant="outlined"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        style={{ marginBottom: 10 }}
      />
      <TableContainer style={{ width: "80%" }} component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell align="center">Mobile</TableCell>
              <TableCell align="center">Check-in Time</TableCell>
              <TableCell align="center">Dropout 1</TableCell>
              <TableCell align="center">Dropout 2</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredData.map((row, index) => (
              <TableRow
                style={{
                  backgroundColor: "red",
                  justifyContent: "space-between",
                  flex: 1,
                  alignItems: "center",
                  alignSelf: "center",
                  textAlign: "center",
                }}
                key={index}
              >
                <TableCell style={{ backgroundColor: "green" }}>{row.mobile}</TableCell>
                <TableCell>{row.checkin_time}</TableCell>
                <TableCell>{String(row.dropout_1)}</TableCell>
                <TableCell>{String(row.dropout_2)}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <TablePagination
        rowsPerPageOptions={[5, 10, 15, 21]}
        component="div"
        count={filteredData.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      /> */}
    </div>
  );
};

ReactTable.propTypes = {
  data: PropTypes.arrayOf(PropTypes.object).isRequired,
  setpageNumber: PropTypes.func.isRequired,
  pageNumber: PropTypes.number.isRequired,
};

export default ReactTable;

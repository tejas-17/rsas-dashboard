import React, { useState, useEffect } from "react";
import axios from "axios";
import Grid from "@mui/material/Grid";
import MDBox from "components/MDBox";
import DashboardLayout from "examples/LayoutContainers/DashboardLayout";
import DashboardNavbar from "examples/Navbars/DashboardNavbar";
import Footer from "examples/Footer";
import TextField from "@mui/material/TextField";
import reportsLineChartData from "layouts/dashboard/data/reportsLineChartData";

import InteractionTable from "./interactionTable";

function InteractionDashboard() {
  const [interactionList, setinteractionList] = useState([]);

  const [PageNumber, setPageNumber] = useState(1);

  const [selectedDate, setSelectedDate] = useState(() => {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    return yesterday.toISOString().split("T")[0];
  });
  const [loading, setLoading] = useState(false); // Initialize loading state

  useEffect(() => {
    fetchData(); // Call fetchData function
  }, [selectedDate, PageNumber]);

  const fetchData = async () => {
    setLoading(true); // Set loading to true when fetching data
    try {
      const Interaction_table_info = await axios.post("http://localhost:8088/daily_interactions", {
        from_time: selectedDate,
        page_no: PageNumber,
      });

      console.log("user data", Interaction_table_info);

      setinteractionList(Interaction_table_info.data.daily_interactions);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false); // Set loading to false after data fetching
    }
  };

  const handleDateChange = (event) => {
    setSelectedDate(event.target.value);
    setPageNumber(1); // Reset the page number to 1 when date changes
  };

  return (
    <DashboardLayout>
      <DashboardNavbar />
      <MDBox py={3}>
        <TextField
          id="date"
          label="Select Date"
          type="date"
          defaultValue={selectedDate}
          onChange={handleDateChange}
          InputLabelProps={{
            shrink: true,
          }}
          style={{
            width: "30%", // Make it take full width
            textAlign: "center", // Center the text
            fontSize: "24px", // Increase the font size
            marginBottom: "40px", // Add some top margin for spacing
            marginLeft: "30%",
          }}
        />
        <Grid container spacing={3}>
          <Grid item xs={12} md={6} lg={6}>
            <InteractionTable
              datax={interactionList}
              setPageNumber={setPageNumber}
              PageNumber={PageNumber}
              loading={loading}
            />
          </Grid>
        </Grid>
      </MDBox>
      <Footer />
    </DashboardLayout>
  );
}

export default InteractionDashboard;
